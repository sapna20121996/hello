import { Component } from "@angular/core";

@Component({
    selector:'two',
    templateUrl:'register.html'

})
export class TwoWay{
  data="Welcome"
  mycolor={'color':'black'}
  display(uname){
   this.data=this.data+ " "+(uname).value;
   this.mycolor.color="red";

  }
  
}